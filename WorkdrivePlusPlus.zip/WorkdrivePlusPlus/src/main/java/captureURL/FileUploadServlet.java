package captureURL;

import java.io.*;
import javax.servlet.http.*;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.fileupload.FileItem;
import org.json.JSONObject;

public class FileUploadServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String oAuthToken = "Zoho-oauthtoken "+getOAuthToken();
//        System.out.println("hello");
        if (oAuthToken == null) {
            response.getWriter().println("Error: OAuth token not found in token_config.json.");
            return;
        }

        String parentId = "8ff1c7d11721b3ff8471b80ff3eb4cdbe3176";

        if (ServletFileUpload.isMultipartContent(request)) {
            try {
                DiskFileItemFactory factory = new DiskFileItemFactory();
                ServletFileUpload upload = new ServletFileUpload(factory);
                FileItem fileItem = upload.parseRequest(request).get(0);

                InputStream fileInputStream = fileItem.getInputStream();
                String filename = fileItem.getName();

                CloseableHttpClient httpClient = HttpClients.createDefault();
                HttpPost uploadFile = new HttpPost("https://www.zohoapis.com/workdrive/api/v1/upload?filename=" + filename + "&override-name-exist=true&parent_id=" + parentId);
                uploadFile.addHeader("Authorization", oAuthToken);

                MultipartEntityBuilder builder = MultipartEntityBuilder.create();
                builder.addBinaryBody("content", fileInputStream, ContentType.APPLICATION_OCTET_STREAM, filename);

                HttpEntity multipart = builder.build();
                uploadFile.setEntity(multipart);

                HttpResponse responseFromZoho = httpClient.execute(uploadFile);

                if (responseFromZoho.getStatusLine().getStatusCode() == 200) {
                    response.getWriter().println("File uploaded successfully!");
                } else {
                    response.getWriter().println("Error uploading file. Status: " + responseFromZoho.getStatusLine());
                }

                httpClient.close();

            } catch (Exception e) {
                e.printStackTrace();
                response.getWriter().println("Error: " + e.getMessage());
            }
        } else {
            response.getWriter().println("Form must have enctype=multipart/form-data.");
        }
    }

    private String getOAuthToken() {
        String token = null;
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("token_config.json")) {
            if (inputStream != null) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder jsonBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    jsonBuilder.append(line);
                }
                // Parse the JSON content
                JSONObject json = new JSONObject(jsonBuilder.toString());
                token = json.optString("access_token");
                System.out.println("OAuth Token: " + token);
            } else {
                System.err.println("Error: token_config.json not found in the classpath.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return token;
    }


}
