package refreshToken;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import org.json.JSONObject;

public class LoadIntoConfig {

    private static final String CONFIG_FILE_PATH = "/home/vijay-zstch1401/IdeaProjects/WorkdrivePlusPlus/src/main/resources/config.properties";
    private static final String TOKEN_FILE_PATH = "/home/vijay-zstch1401/IdeaProjects/WorkdrivePlusPlus/src/main/resources/token_config.json";

    public static void main(String[] args) {
        try {
            String clientId = getConfig("client_id");
            String clientSecret = getConfig("client_secret");
            String refreshToken = getConfig("refresh_token");

            String apiUrl = "https://accounts.zoho.com/oauth/v2/token";
            String parameters ="refresh_token="+refreshToken+"&client_secret="+clientSecret+"&grant_type=refresh_token&client_id="+clientId;

            String response = sendPostRequest(apiUrl, parameters);
            JSONObject jsonResponse = new JSONObject(response);
            saveTokenConfig(jsonResponse);

            System.out.println("Token saved successfully");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static String getConfig(String key) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(CONFIG_FILE_PATH));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] keyValue = line.split("=");
            if (keyValue[0].trim().equals(key)) {
                return keyValue[1].trim();
            }
        }
        reader.close();
        return null;
    }

    private static String sendPostRequest(String apiUrl, String parameters) throws IOException {
        URL url = new URL(apiUrl);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");
        connection.setDoOutput(true);
        connection.getOutputStream().write(parameters.getBytes(StandardCharsets.UTF_8));

        BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
        StringBuilder response = new StringBuilder();
        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            response.append(inputLine);
        }
        in.close();

        return response.toString();
    }

    private static void saveTokenConfig(JSONObject jsonResponse) throws IOException {
        FileWriter writer = new FileWriter(TOKEN_FILE_PATH);
        writer.write(jsonResponse.toString(4));
        writer.close();
    }
}
