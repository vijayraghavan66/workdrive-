package getfilesfromfolder;

import javax.servlet.ServletException;
import javax.servlet.http.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONArray;
import org.json.JSONObject;

public class FetchFilesServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String apiUrlWithFolderId = "https://www.zohoapis.com/workdrive/api/v1/files/8ff1c7d11721b3ff8471b80ff3eb4cdbe3176/files?page%5Blimit%5D=50&page%5Boffset%5D=0"; // Replace {folder_id} with your folder ID
     // Replace with your actual Bearer token

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try {


            // Make the GET request to Zoho WorkDrive API
            URL url = new URL(apiUrlWithFolderId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Bearer " + getOAuthToken());

            // Read the response from Zoho WorkDrive API
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder responseBuilder = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                responseBuilder.append(inputLine);
            }
            in.close();

            // Parse the response JSON
            JSONObject responseObject = new JSONObject(responseBuilder.toString());

            // Get file details from the response
            JSONArray filesData = responseObject.getJSONArray("data");

            // Create a JSON response for the HTML page
            JSONObject jsonResponse = new JSONObject();
            JSONArray files = new JSONArray();

            // Loop through the files and add them to the JSON array
            for (int i = 0; i < filesData.length(); i++) {
                JSONObject file = filesData.getJSONObject(i);
                String fileName = file.getJSONObject("attributes").getString("name");
                String fileId = file.getString("id");
                String fileType = file.getJSONObject("attributes").getString("type");

                JSONObject fileJson = new JSONObject();
                fileJson.put("name", fileName);
                fileJson.put("id", fileId);
                fileJson.put("type", fileType);

                files.put(fileJson);
            }

            jsonResponse.put("files", files);

            // Send the JSON response
            out.println(jsonResponse);

        } catch (Exception e) {
            e.printStackTrace();
            JSONObject errorResponse = new JSONObject();
            errorResponse.put("error", "Failed to fetch files: " + e.getMessage());
            out.println(errorResponse);
        } finally {
            out.close();
        }
    }
    private String getOAuthToken() {
        String token = null;
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("token_config.json")) {
            if (inputStream != null) {
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder jsonBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    jsonBuilder.append(line);
                }
                // Parse the JSON content
                JSONObject json = new JSONObject(jsonBuilder.toString());
                token = json.optString("access_token");
                System.out.println("OAuth Token: " + token);
            } else {
                System.err.println("Error: token_config.json not found in the classpath.");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return token;
    }
}
